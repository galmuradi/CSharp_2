﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * BaseTest
 */

using NUnit.Framework;
using OpenQA.Selenium;
using System;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using System.Runtime.CompilerServices;

namespace ESDC.CPPE.FunctionalTests
{
    public class BaseTest : SeleniumDriverFactory
    {
        private IWebDriver driver;
        private ExtentReports extent = null;
        private ExtentTest test = null;
        public static string TestResultDirectory;

        private static string dateTime = DateTime.Now.ToString("yyyy-MM-dd HH.mm.ss");

        public static string UserName { get; }

        /**
         * Set up the HTML report
         */
        public void OneTimeSetup(ExtentTest test, [CallerMemberName] string memberName = "")
        {
            extent = new ExtentReports();
            var htmlReport = new ExtentHtmlReporter(@"C:\TestAutomation\Deploy_" + Environment.MachineName + "_" + Environment.UserName + "_" + dateTime + @"\" + TestContext.CurrentContext.Test.ClassName + @"\" + "report.html");
            extent.AttachReporter(htmlReport);
            this.test = test;
        }

        /**
         *Set up the driver  
         */
        public void Setup()
        {
            string testName = string.Format("{0}.{1}", TestContext.CurrentContext.Test.ClassName, TestContext.CurrentContext.Test.MethodName);
            test = extent.CreateTest(TestContext.CurrentContext.Test.MethodName).Info("..... SetUp .....");
            base.SetDriver(driver, test);
            this.driver = base.GetDriver();
            driver.Manage().Cookies.DeleteAllCookies();
            driver.Manage().Window.Maximize();
            driver.SwitchTo().ActiveElement().SendKeys(Keys.Control + "0");
            test.Log(Status.Info, "Test Executed by: " + Environment.UserName);
            test.Log(Status.Info, "Started With Testing Using Browser: " + BrowserName);
            test.Log(Status.Info, "Testing Page: " + BaseURL);
            test.Log(Status.Info, " ... Test Execution ... ");
            test.Log(Status.Info, "Started With Scenario: " + testName);
        }

        /**
         * Determine if a test is passed or failed
         */
        public void TearDown()
        {
            string testName = string.Format("{0}.{1}", TestContext.CurrentContext.Test.ClassName, TestContext.CurrentContext.Test.MethodName);
            string currentTestOutcome = TestContext.CurrentContext.Result.Outcome.Status.ToString();
            string message = string.Format("Test '{0}' {1}", testName, currentTestOutcome.ToString().ToUpperInvariant());
            if (!currentTestOutcome.Equals("Passed"))
            {
                test.Log(Status.Fail, message);
            }
            else
            {
                test.Log(Status.Pass, message);
            }

            driver.Close();
            driver.Quit();
        }

        /**
         * Create the HTML report
         */
        public void OneTimeTearDown()
        {
            extent.Flush();
        }

        public new IWebDriver GetDriver()
        {
            return driver;
        }

        public ExtentTest GetTest()
        {
            return test;
        }
    }
}