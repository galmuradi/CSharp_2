﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * ITRDS HomePage: ITRDS HomePage Testing Scenarios
 */

using NUnit.Framework;
using System;
using OpenQA.Selenium;
using ESDC.CPPE.FunctionalTests.TestObjects;
using AventStack.ExtentReports;


namespace ESDC.CPPE.FunctionalTests
{
    [TestFixture]
    class ITRDS_HomePage : BaseTest
    {
        private IWebDriver driver;
        private ExtentTest test = null;

        public static string pageUrl = TestContext.Parameters["baseUrl"]?.ToString();
        public static string pageTitle = TestContext.Parameters["pageTitle"]?.ToString();

        public static string englishPageUrl = TestContext.Parameters["englishUrl"]?.ToString();
        public static string frenchPageUrl = TestContext.Parameters["frenchUrl"]?.ToString();

        public static string findClientEnglishPageUrl = TestContext.Parameters["findClientEnglishUrl"]?.ToString();
        public static string findClientFrenchPageUrl = TestContext.Parameters["findClientFrenchhUrl"]?.ToString();

        public static string enLoginPageTitle = TestContext.Parameters["enLoginPageTitle"]?.ToString();
        public static string frLoginPageTitle = TestContext.Parameters["frLoginPageTitle"]?.ToString();

        public static string terminateUrl = TestContext.Parameters["terminateUrl"]?.ToString();

        public static string logoutPageUrl = TestContext.Parameters["logoutUrl"]?.ToString();

        /**
         * Method to call OneTimeSetUp() from BaseTest to avoid code repetition
         * Method is called only once per test class
         */
        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            base.OneTimeSetup(test);
        }

        /**
         * Method to call SetUp() from BaseTest
         * Method is called after every test scenario
         */
        [SetUp]
        public new void Setup()
        {
            base.Setup();
            this.driver = base.GetDriver();
            this.test = base.GetTest();
        }

        /**
         * Method to call TearDown() from BaseTest
         * Method is called after every test scenario
         */
        [TearDown]
        public new void TearDown()
        {
            base.TearDown();
        }

        /**
         * Method to call OneTimeTearDown() from BaseTest
         * Method is only called when all test scenarios are done running
         */
        [OneTimeTearDown]
        public new void OneTimeTearDown()
        {
            base.OneTimeTearDown();
        }



        //***********************************************************************************//
        //**                                  Scenario 1                                   **//
        //** ITRDS Home Page: URL, Title, English Button, French Button, Ok Button         **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_HomePageElements()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(this.driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);

            //ITRDS Home Page: URL
            String actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(pageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked Base Page URL: " + pageUrl + TestContext.CurrentContext.Test.MethodName);

            //ITRDS Home Page: Title
            String actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(pageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked Page Title: " + pageTitle + TestContext.CurrentContext.Test.MethodName);

            //ITRDS Home Page Elements: Buttons
            //ITRDS Home Page English Button
            homePage.ClickElement(homePageElements.itrdsEnglish);
            //Engish Login Page: URL
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertPartialText(englishPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked English Login Page URL: " + englishPageUrl + TestContext.CurrentContext.Test.MethodName);

            //English Login Page: Title
            actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(enLoginPageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked English Login Page Title: " + enLoginPageTitle + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "Checked English Button: " + TestContext.CurrentContext.Test.MethodName);

            //ITRDS Home Page English Button
            homePage.NavigateBackward();
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(pageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked Back Arrow Icon: " + TestContext.CurrentContext.Test.MethodName);

            //ITRDS Home Page French Button
            homePage.ClickElement(homePageElements.itrdsFrench);
            //French Login Page: URL
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertPartialText(frenchPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked French Login Page URL: " + frenchPageUrl + TestContext.CurrentContext.Test.MethodName);

            //French Login Page: Title
            actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(frLoginPageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked French Login Page Title: " + frLoginPageTitle + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "Checked French Button: " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


        //***********************************************************************************//
        //**                                  Scenario 2                                   **//
        //** ITRDS Home Page - English: Login, Logout                                      **// 
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_Login_Logout()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);

            //Click English Button
            homePage.ClickElement(homePageElements.itrdsEnglish);

            //Provide Credintials and Login
            homePage.LoginCredentials(homePageElements.userName, homePageElements.userPass, homePageElements.btnOk);
            String actualPageTitle = homePage.GetPageTitle();
            if (actualPageTitle.Equals("Terminate Session"))
            {
                homePage.ClickElement(homePageElements.btnTerminate);
                var actualTerminatePageUrl = homePage.GetPageUrl();
                homePage.AssertText(terminateUrl, actualTerminatePageUrl);
                homePage.ClickElement(homePageElements.btnLogOut);

                //Landing on ITRDS page
                homePage.GotoUrl(pageUrl);

                //Click English Button
                homePage.ClickElement(homePageElements.itrdsEnglish);

                //Provide Credintials and Login
                homePage.LoginCredentials(homePageElements.userName, homePageElements.userPass, homePageElements.btnOk);

            }
            String actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(findClientEnglishPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked English Login: " + TestContext.CurrentContext.Test.MethodName);

            //Logout
            homePage.ClickElement(homePageElements.btnLogOut);
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(logoutPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked English Logout: " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "Checked English Login - Logout. " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


        //***********************************************************************************//
        //**                                  Scenario 3                                   **//
        //** ITRDS Home Page - French: Login, Logout                                       **// 
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_French_Login_Logout()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();


            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);

            //Click French Button
            homePage.ClickElement(homePageElements.itrdsFrench);

            //Provide Credintials and Login
            homePage.LoginCredentials(homePageElements.userName, homePageElements.userPass, homePageElements.btnOk);
            String actualPageTitle = homePage.GetPageTitle();
            if (actualPageTitle.Equals("Terminate Session"))
            {
                homePage.ClickElement(homePageElements.btnTerminate);
            }
            String actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(findClientEnglishPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked Fench Login: " + TestContext.CurrentContext.Test.MethodName);

            //Logout
            homePage.ClickElement(homePageElements.btnLogOut);
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(logoutPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked French Logout: " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "Checked French Login - Logout. " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }






    }
}
