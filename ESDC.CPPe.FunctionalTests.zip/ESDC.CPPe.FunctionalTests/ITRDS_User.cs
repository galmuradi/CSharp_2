﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * ITRDS User: User Testing Scenarios
 */

using NUnit.Framework;
using OpenQA.Selenium;
using ESDC.CPPE.FunctionalTests.TestObjects;
using AventStack.ExtentReports;


namespace ESDC.CPPE.FunctionalTests
{
    [TestFixture]
    public class ITRDS_User : BaseTest
    {
        private IWebDriver driver;
        private ExtentTest test = null;

        public static string googleUrl = TestContext.Parameters["googleUrl"]?.ToString();
        public static string text4 = TestContext.Parameters["text4"]?.ToString();

        public static string pageUrl = TestContext.Parameters["baseUrl"]?.ToString();
        public static string pageTitle = TestContext.Parameters["pageTitle"]?.ToString();

        public static string englishPageUrl = TestContext.Parameters["englishUrl"]?.ToString();
        public static string frenchPageUrl = TestContext.Parameters["frenchUrl"]?.ToString();

        public static string findClientEnglishPageUrl = TestContext.Parameters["findClientEnglishUrl"]?.ToString();
        public static string findClientFrenchPageUrl = TestContext.Parameters["findClientFrenchhUrl"]?.ToString();

        public static string userUrl = TestContext.Parameters["userUrl"]?.ToString();
        public static string userPageTitle = TestContext.Parameters["userPageTitle"]?.ToString();
        public static string userSearchAlert = TestContext.Parameters["userSearchAlert"]?.ToString();
        public static string userAddPageTitle = TestContext.Parameters["userAddPageTitle"]?.ToString();
        public static string userCancelUrl = TestContext.Parameters["userCancelUrl"]?.ToString();

        public static string newUserId = TestContext.Parameters["newUserId"]?.ToString();
        public static string userId = TestContext.Parameters["userId"]?.ToString();
        public static string userFirstName = TestContext.Parameters["userFirstName"]?.ToString();
        public static string userSurname = TestContext.Parameters["userSurname"]?.ToString();

        public static string terminateUrl = TestContext.Parameters["terminateUrl"]?.ToString();

        public static string labelUserFirstName = TestContext.Parameters["labelUserFirstName"]?.ToString();
        public static string labelUserSurname = TestContext.Parameters["labelUserSurname"]?.ToString();
        public static string labelUserId = TestContext.Parameters["labelUserId"]?.ToString();

        public static string labelNotFoundSearchResult = TestContext.Parameters["labelNotFoundSearchResult"]?.ToString();


        public static string logoutPageUrl = TestContext.Parameters["logoutUrl"]?.ToString();

        /**
         * Method to call OneTimeSetUp() from BaseTest to avoid code repetition
         * Method is called only once per test class
         */
        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            base.OneTimeSetup(test);
        }

        /**
         * Method to call SetUp() from BaseTest
         * Method is called after every test scenario
         */
        [SetUp]
        public new void Setup()
        {
            base.Setup();
            this.driver = base.GetDriver();
            this.test = base.GetTest();
        }

        /**
         * Method to call TearDown() from BaseTest
         * Method is called after every test scenario
         */
        [TearDown]
        public new void TearDown()
        {
            base.TearDown();
        }

        /**
         * Method to call OneTimeTearDown() from BaseTest
         * Method is only called when all test scenarios are done running
         */
        [OneTimeTearDown]
        public new void OneTimeTearDown()
        {
            base.OneTimeTearDown();
        }


        //***********************************************************************************//
        //**                                  Scenario 1                                   **//
        //** ITRDS User Home Page: URL, Title, Search Button, Add Button, Cancel Button    **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_FindClient_UserPageElements()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS English page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsEnglish, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientEnglishPageUrl);

            //Click User Link
            homePage.ClickElement(homePageElements.userLink);
            test.Log(Status.Info, "Checked User Link in Find Client Page. " + TestContext.CurrentContext.Test.MethodName);

            //User Page: URL
            string actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(userUrl, actualPageUrl);
            test.Log(Status.Info, "Checked User Page URL: " + userUrl + TestContext.CurrentContext.Test.MethodName);

            //User Page: Title
            string actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(userPageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked User Page Title: " + userPageTitle + TestContext.CurrentContext.Test.MethodName);

            //User Page Elements: Input Boxes
            homePage.AssertElementLable(homePageElements.labelFirstName, labelUserFirstName);
            homePage.AssertElementLable(homePageElements.labelSurname, labelUserSurname);
            homePage.AssertElementLable(homePageElements.labelUserId, labelUserId);

            homePage.InputText(homePageElements.inputFirstName, userFirstName);
            homePage.InputText(homePageElements.inputSurname, userSurname);
            homePage.InputText(homePageElements.inputUserId, userId);

            homePage.ClearInputText(homePageElements.inputFirstName);
            homePage.ClearInputText(homePageElements.inputSurname);
            homePage.ClearInputText(homePageElements.inputUserId);

            //User Page Elements: Buttons
            //User Page Reset Button
            //User Page Search Button
            homePage.ClickElement(homePageElements.btnSearch);
            homePage.Alert(userSearchAlert);
            test.Log(Status.Info, "Checked Search Button - Alert is Generated: " + TestContext.CurrentContext.Test.MethodName);

            //User Page Add Button
            homePage.ClickElement(homePageElements.btnAdd);
            //actualPageUrl = homePage.GetPageUrl();
            //homePage.AssertText(pageUrl, actualPageUrl);
            actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(userAddPageTitle, actualPageTitle);
            homePage.ClickElement(homePageElements.btnCancel);
            test.Log(Status.Info, "Checked Add Button: " + TestContext.CurrentContext.Test.MethodName);

            //User Page Cancel Button
            //       homePage.ClickElement(homePageElements.btnCancel);
            //       actualPageUrl = homePage.GetPageUrl();
            //       homePage.AssertPartialText(userCancelUrl, actualPageUrl);
            //       test.Log(Status.Info, "Checked Cancel Button: " + TestContext.CurrentContext.Test.MethodName);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnUserLogOut);
            actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(logoutPageUrl, actualPageUrl);
            test.Log(Status.Info, "Checked English Logout: " + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


        //***********************************************************************************//
        //**                                  Scenario 2                                   **//
        //** ITRDS User: Search Functionality                                              **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_FindClient_User_Search()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS English page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsEnglish, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientEnglishPageUrl);

            //Click User Link
            homePage.ClickElement(homePageElements.userLink);
            string actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(userPageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked User Page Title: " + userPageTitle + TestContext.CurrentContext.Test.MethodName);

            //User Page Search Button
            homePage.InputText(homePageElements.inputUserId, newUserId);
            homePage.ClickElement(homePageElements.btnSearch);
            homePage.AssertElementLable(homePageElements.labelNotFoundInfo, labelNotFoundSearchResult);
            test.Log(Status.Info, "Checked Search Button: " + labelNotFoundSearchResult + " " + TestContext.CurrentContext.Test.MethodName);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnUserLogOut);


            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }

        //***********************************************************************************//
        //**                                  Scenario 3                                   **//
        //** ITRDS User: Add Functionality                                                 **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_FindClient_User_Add()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(this.driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS English page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsEnglish, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientEnglishPageUrl);

            //Click User Link
            homePage.ClickElement(homePageElements.userLink);
            string actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(userPageTitle, actualPageTitle);
            test.Log(Status.Info, "Checked User Page Title: " + userPageTitle + TestContext.CurrentContext.Test.MethodName);

            //User Page Search Button
            homePage.InputText(homePageElements.inputUserId, userId);
            homePage.ClickElement(homePageElements.btnSearch);
            if (homePage.DoesLabelEist(homePageElements.labelNotFoundInfo, labelNotFoundSearchResult))
            {
                //Add a User
                homePage.InputText(homePageElements.inputFirstName, userFirstName);
                homePage.InputText(homePageElements.inputSurname, userSurname);
                homePage.InputText(homePageElements.inputUserId, userId);
                homePage.ClickElement(homePageElements.btnAdd);
                homePage.ClickElement(homePageElements.btnCancel);
            }

            test.Log(Status.Info, "Checked Add Button: " + TestContext.CurrentContext.Test.MethodName);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnUserLogOut);


            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }



        //***********************************************************************************//
        //**                                  Scenario 4                                   **//
        //** ITRDS User: Cancel Functionality                                              **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_FindClient_User_Cancel()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);

            //Click English Button
            //homePage.ClickElement(homePageElements.itrdsEnglishxxx);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }



        //***********************************************************************************//
        //**                                  Scenario 5                                   **//
        //** ITRDS User: Add Functionality                                                 **//
        //***********************************************************************************//
        [Test]
        public void Test_Fail1()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(this.driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);
            string actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText("http://www.google.com", actualPageUrl);

            homePage.InputText(homePageElements.googleSearch, text4);
            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


        //***********************************************************************************//
        //**                                  Scenario 6                                   **//
        //** ITRDS User: Cancel Functionality                                              **//
        //***********************************************************************************//
        [Test]
        public void Test_Fail2()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS page
            homePage.GotoUrl(pageUrl);

            //Click English Button
            homePage.ClickElement(homePageElements.itrdsEnglishxxx);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }








    }
}