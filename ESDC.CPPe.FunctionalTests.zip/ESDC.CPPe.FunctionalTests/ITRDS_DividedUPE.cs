﻿/**
 * DividedUPE: DividedUPE Testing Scenarios
 */

using NUnit.Framework;
using OpenQA.Selenium;
using ESDC.CPPE.FunctionalTests.TestObjects;
using AventStack.ExtentReports;
using System.Threading;

namespace ESDC.CPPE.FunctionalTests
{
    [TestFixture]
    public class ITRDS_DividedUPE : BaseTest
    {
        private IWebDriver driver;
        private ExtentTest test = null;

        public static string googleUrl = TestContext.Parameters["googleUrl"]?.ToString();
        public static string text4 = TestContext.Parameters["text4"]?.ToString();

        public static string pageUrl = TestContext.Parameters["baseUrl"]?.ToString();
        public static string pageTitle = TestContext.Parameters["pageTitle"]?.ToString();

        public static string englishPageUrl = TestContext.Parameters["englishUrl"]?.ToString();
        public static string frenchPageUrl = TestContext.Parameters["frenchUrl"]?.ToString();

        public static string findClientEnglishPageUrl = TestContext.Parameters["findClientEnglishUrl"]?.ToString();
        public static string findClientFrenchPageUrl = TestContext.Parameters["findClientFrenchUrl"]?.ToString();

        public static string clientProfileEnglishUrl = TestContext.Parameters["clientProfileEnglishUrl"]?.ToString();
        public static string clientProfilePageEngTitle = TestContext.Parameters["clientProfilePageEngTitle"]?.ToString();

        public static string creditSplettingEnglishUrl = TestContext.Parameters["creditSplettingEnglishUrl"]?.ToString();
        public static string creditSplettingPageEngTitle = TestContext.Parameters["creditSplettingPageEngTitle"]?.ToString();
        public static string creditSplettingPageFrTitle = TestContext.Parameters["frCreditSplitting"]?.ToString();

        public static string dividedUPEEnglishUrl = TestContext.Parameters["dividedUPEEnglishUrl"]?.ToString();
        public static string dividedUPEPageEngTitle = TestContext.Parameters["dividedUPEPageEngTitle"]?.ToString();


        public static string dividedUPEYear = TestContext.Parameters["dividedUPEYear"]?.ToString();
        public static string dividedUPEClient = TestContext.Parameters["dividedUPEClient"]?.ToString();
        public static string dividedUPEClientCPPUPE = TestContext.Parameters["dividedUPEClientCPPUPE"]?.ToString();
        public static string dividedUPEClientCPPUPEBef = TestContext.Parameters["dividedUPEClientCPPUPEBef"]?.ToString();
        public static string dividedUPEClientCPPUPEAft = TestContext.Parameters["dividedUPEClientCPPUPEAft"]?.ToString();
        public static string dividedUPEClientQPPDivided = TestContext.Parameters["dividedUPEClientQPPDivided"]?.ToString();
        public static string dividedUPEClientCPPReason = TestContext.Parameters["dividedUPEClientCPPReason"]?.ToString();

        public static string dividedUPESpouse = TestContext.Parameters["dividedUPESpouse"]?.ToString();
        public static string dividedUPESpouseSIN = TestContext.Parameters["dividedUPESpouseSIN"]?.ToString();
        public static string dividedUPESpouseCPPUPE = TestContext.Parameters["dividedUPESpouseCPPUPE"]?.ToString();
        public static string dividedUPESpouseCPPUPEBef = TestContext.Parameters["dividedUPESpouseCPPUPEBef"]?.ToString();
        public static string dividedUPESpouseCPPUPEAft = TestContext.Parameters["dividedUPESpouseCPPUPEAft"]?.ToString();
        public static string dividedUPESpouseQPPDivided = TestContext.Parameters["dividedUPESpouseQPPDivided"]?.ToString();
        public static string dividedUPESpouseCPPReason = TestContext.Parameters["dividedUPESpouseCPPReason"]?.ToString();

        public static string dividedUPEYearFr = TestContext.Parameters["dividedUPEYearFr"]?.ToString();
        public static string dividedUPEClientFr = TestContext.Parameters["dividedUPEClientFr"]?.ToString();
        public static string dividedUPEClientCPPUPEFr = TestContext.Parameters["dividedUPEClientCPPUPEFr"]?.ToString();
        public static string dividedUPEClientCPPUPEBefFr = TestContext.Parameters["dividedUPEClientCPPUPEBefFr"]?.ToString();
        public static string dividedUPEClientCPPUPEAftFr = TestContext.Parameters["dividedUPEClientCPPUPEAftFr"]?.ToString();
        public static string dividedUPEClientQPPDividedFr = TestContext.Parameters["dividedUPEClientQPPDividedFr"]?.ToString();
        public static string dividedUPEClientCPPReasonFr = TestContext.Parameters["dividedUPEClientCPPReasonFr"]?.ToString();

        public static string dividedUPESpouseFr = TestContext.Parameters["dividedUPESpouseFr"]?.ToString();
        public static string dividedUPESpouseSINFr = TestContext.Parameters["dividedUPESpouseSINFr"]?.ToString();
        public static string dividedUPESpouseCPPUPEFr = TestContext.Parameters["dividedUPESpouseCPPUPEFr"]?.ToString();
        public static string dividedUPESpouseCPPUPEBefFr = TestContext.Parameters["dividedUPESpouseCPPUPEBefFr"]?.ToString();
        public static string dividedUPESpouseCPPUPEAftFr = TestContext.Parameters["dividedUPESpouseCPPUPEAftFr"]?.ToString();
        public static string dividedUPESpouseQPPDividedFr = TestContext.Parameters["dividedUPESpouseQPPDividedFr"]?.ToString();
        public static string dividedUPESpouseCPPReasonFr = TestContext.Parameters["dividedUPESpouseCPPReasonFr"]?.ToString();


        public static string userUrl = TestContext.Parameters["userUrl"]?.ToString();
        public static string userPageTitle = TestContext.Parameters["userPageTitle"]?.ToString();
        public static string userSearchAlert = TestContext.Parameters["userSearchAlert"]?.ToString();
        public static string userCancelUrl = TestContext.Parameters["userCancelUrl"]?.ToString();

        public static string userSIN = TestContext.Parameters["userSIN"]?.ToString();
        public static string clientProfilePageTitle = TestContext.Parameters["clientProfilePageTitle"]?.ToString();


        public static string logoutPageUrl = TestContext.Parameters["logoutUrl"]?.ToString();


        /**
         * Method to call OneTimeSetUp() from BaseTest to avoid code repetition
         * Method is called only once per test class
         */
        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            base.OneTimeSetup(test);
        }

        /**
         * Method to call SetUp() from BaseTest
         * Method is called after every test scenario
         */
        [SetUp]
        public new void Setup()
        {
            base.Setup();
            this.driver = base.GetDriver();
            this.test = base.GetTest();
        }

        /**
         * Method to call TearDown() from BaseTest
         * Method is called after every test scenario
         */
        [TearDown]
        public new void TearDown()
        {
            base.TearDown();
        }

        /**
         * Method to call OneTimeTearDown() from BaseTest
         * Method is only called when all test scenarios are done running
         */
        [OneTimeTearDown]
        public new void OneTimeTearDown()
        {
            base.OneTimeTearDown();
        }


        //*************************************************************************************************************//
        //**                                                Scenario 1                                               **//
        //**                                                 English                                                 **//
        //** Divided UPE Page: Client-Spouse Table Headers:                                                          **//
        //** Year                                                                                                    **// 
        //** Client, CPP UPE (Before, After), QPP Divided UPE, CPP Reason Code (Legend)                              **//
        //** Spouse / Common-law Partner, SIN, CPP UPE (Before, After), QPP Divided UPE, CPP Reason Code (Legend)    **//
        //*************************************************************************************************************//
        [Test]
        public void Test_ITRDS_English_DividedUPE_ClientSpouseTable()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS English page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsEnglish, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientEnglishPageUrl);

            //Provide Identifier/SIN number and Search
            homePage.InputText(homePageElements.inputIdentifier, userSIN);
            homePage.ClickElement(homePageElements.btnClientSearch);

            //Click Credit Splitting
            //homePage.ClickElement(homePageElements.englishCreditSplittingLink);
            homePage.ClickMenu(homePageElements.englishCreditSplittingLink, creditSplettingPageEngTitle);

            //Click Divided UPE
            homePage.ClickElement(homePageElements.englishDividedUPELink);

            //Divided UPE: Client-Spouse Table Headers
            Thread.Sleep(10000);
            homePage.AssertElementLable(homePageElements.yearHeader, dividedUPEYear);

            homePage.AssertElementLable(homePageElements.clientHeader, dividedUPEClient);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPE, dividedUPEClientCPPUPE);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPEBef, dividedUPEClientCPPUPEBef);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPEAft, dividedUPEClientCPPUPEAft);
            homePage.AssertElementLable(homePageElements.clientHeaderQPPDivided, dividedUPEClientQPPDivided);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPReason, dividedUPEClientCPPReason);

            homePage.AssertElementLable(homePageElements.SpouseHeader, dividedUPESpouse);
            homePage.AssertElementLable(homePageElements.SpouseHeaderSIN, dividedUPESpouseSIN);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPE, dividedUPESpouseCPPUPE);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPEBef, dividedUPESpouseCPPUPEBef);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPEAft, dividedUPESpouseCPPUPEAft);
            homePage.AssertElementLable(homePageElements.SpouseHeaderQPPDivided, dividedUPESpouseQPPDivided);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPReason, dividedUPESpouseCPPReason);

            test.Log(Status.Info, "Checked English Client-Spouse Table Headers. " + TestContext.CurrentContext.Test.MethodName);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnLogOut);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


        //*************************************************************************************************************//
        //**                                                Scenario 2                                               **//
        //**                                                 French                                                  **//
        //** Divided UPE Page: Client-Spouse Table Headers:                                                          **//
        //** Année                                                                                                   **// 
        //** Client, GNAP RPC (Avant, Après), GNAP RRQ Partagé, Code de raison RPC (Légende)                         **//
        //** Époux / Conjoint de fait, NAS, GNAP RPC (Avant, Après), GNAP RRQ Partagé, Code de raison RPC (Légende)  **//
        //*************************************************************************************************************//
        [Test]
        public void Test_ITRDS_French_DividedUPE_ClientSpouseTable()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS French page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsFrench, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientFrenchPageUrl);

            //Provide Identifier/SIN number and Search
            homePage.InputText(homePageElements.inputIdentifier, userSIN);
            homePage.ClickElement(homePageElements.btnClientSearch);

            //Click Credit Splitting
            //homePage.ClickElement(homePageElements.frenchCreditSplittingLink);
            homePage.ClickMenu(homePageElements.frenchCreditSplittingLink, creditSplettingPageFrTitle);

            //Click Divided UPE
            homePage.ClickElement(homePageElements.frenchDividedUPELink);


            //Divided UPE: Client-Spouse Table Headers
            Thread.Sleep(10000);
            homePage.AssertElementLable(homePageElements.yearHeader, dividedUPEYearFr);

            homePage.AssertElementLable(homePageElements.clientHeader, dividedUPEClientFr);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPE, dividedUPEClientCPPUPEFr);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPEBef, dividedUPEClientCPPUPEBefFr);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPUPEAft, dividedUPEClientCPPUPEAftFr);
            homePage.AssertElementLable(homePageElements.clientHeaderQPPDivided, dividedUPEClientQPPDividedFr);
            homePage.AssertElementLable(homePageElements.clientHeaderCPPReason, dividedUPEClientCPPReasonFr);

            homePage.AssertElementLable(homePageElements.SpouseHeader, dividedUPESpouseFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderSIN, dividedUPESpouseSINFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPE, dividedUPESpouseCPPUPEFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPEBef, dividedUPESpouseCPPUPEBefFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPUPEAft, dividedUPESpouseCPPUPEAftFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderQPPDivided, dividedUPESpouseQPPDividedFr);
            homePage.AssertElementLable(homePageElements.SpouseHeaderCPPReason, dividedUPESpouseCPPReasonFr);

            test.Log(Status.Info, "Checked French Client-Spouse Table Headers. " + TestContext.CurrentContext.Test.MethodName);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnLogOut);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }






    }
}

