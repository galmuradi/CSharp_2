﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * SeleniumDriverFactory
 */

using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System.IO;
using AventStack.ExtentReports;


namespace ESDC.CPPE.FunctionalTests
{
    public class SeleniumDriverFactory
    {
        private IWebDriver driver;

        public static string DriverFolderPath;
        public static string BrowserName;
        public static string BaseURL;
        public TestContext testContext { get; set; }

        /**
         * Choose the right driver to be used
         */
        public void SetDriver(IWebDriver driver, ExtentTest test)
        {
            DriverFolderPath = TestContext.Parameters["DriverFolderPath"]?.ToString();
            BrowserName = TestContext.Parameters["browser"]?.ToString();
            BaseURL = TestContext.Parameters["baseUrl"]?.ToString();

            string testDirectory = TestContext.CurrentContext.TestDirectory;
            string solution_dir = Directory.GetParent(testDirectory).Parent.FullName;
            string main_dir = Path.GetDirectoryName(solution_dir);
            var webDriversPath = Path.Combine(solution_dir, DriverFolderPath);
            if (BrowserName.Equals("Chrome"))
            {
                //http123://chromedriver.storage.googleapis.com/index.html
                var chromeOptions = new ChromeOptions();
                chromeOptions.AddAdditionalCapability("useAutomationExtension", false);
                driver = new ChromeDriver(@webDriversPath, chromeOptions);
            }

            else if (BrowserName.Equals("Firefox"))
            {
                //https123://github.com/mozilla/geckodriver/releases/tag/v0.26.0
                var options = new FirefoxOptions();
                options.AcceptInsecureCertificates = true;
                driver = new FirefoxDriver(@webDriversPath, options);
            }

            else if (BrowserName.Equals("IE"))
            {
                //https123://selenium-release.storage.googleapis.com/3.150/IEDriverServer_Win32_3.150.0.zip
                var options = new InternetExplorerOptions();
                options.IgnoreZoomLevel = true;
                options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                driver = new InternetExplorerDriver(@webDriversPath, options);
            }

            else
            {
                test.Log(Status.Error, "Please Provide the Correct Browser Name! The Browser Name is not Defined: " + BrowserName);
            }

            this.driver = driver;
        }

        public IWebDriver GetDriver()
        {
            return driver;
        }

    }
}