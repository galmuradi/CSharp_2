﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * ClientProfile: ClientProfile Testing Scenarios
 */

using NUnit.Framework;
using OpenQA.Selenium;
using ESDC.CPPE.FunctionalTests.TestObjects;
using AventStack.ExtentReports;
using System.Threading;

namespace ESDC.CPPE.FunctionalTests
{
    [TestFixture]
    public class ITRDS_ClientProfile : BaseTest
    {
        private IWebDriver driver;
        private ExtentTest test = null;

        public static string googleUrl = TestContext.Parameters["googleUrl"]?.ToString();
        public static string text4 = TestContext.Parameters["text4"]?.ToString();

        public static string pageUrl = TestContext.Parameters["baseUrl"]?.ToString();
        public static string pageTitle = TestContext.Parameters["pageTitle"]?.ToString();

        public static string englishPageUrl = TestContext.Parameters["englishUrl"]?.ToString();
        public static string frenchPageUrl = TestContext.Parameters["frenchUrl"]?.ToString();

        public static string findClientEnglishPageUrl = TestContext.Parameters["findClientEnglishUrl"]?.ToString();
        public static string findClientFrenchPageUrl = TestContext.Parameters["findClientFrenchhUrl"]?.ToString();

        public static string clientProfileEnglishUrl = TestContext.Parameters["clientProfileEnglishUrl"]?.ToString();
        public static string clientProfilePageEngTitle = TestContext.Parameters["clientProfilePageEngTitle"]?.ToString();

        public static string creditSplettingEnglishUrl = TestContext.Parameters["creditSplettingEnglishUrl"]?.ToString();
        public static string creditSplettingPageEngTitle = TestContext.Parameters["creditSplettingPageEngTitle"]?.ToString();


        public static string userUrl = TestContext.Parameters["userUrl"]?.ToString();
        public static string userPageTitle = TestContext.Parameters["userPageTitle"]?.ToString();
        public static string userSearchAlert = TestContext.Parameters["userSearchAlert"]?.ToString();
        public static string userCancelUrl = TestContext.Parameters["userCancelUrl"]?.ToString();

        public static string userSIN = TestContext.Parameters["userSIN"]?.ToString();
        public static string clientProfilePageTitle = TestContext.Parameters["clientProfilePageTitle"]?.ToString();

        //public static string terminateUrl = TestContext.Parameters["terminateUrl"]?.ToString();

        public static string logoutPageUrl = TestContext.Parameters["logoutUrl"]?.ToString();


        /**
         * Method to call OneTimeSetUp() from BaseTest to avoid code repetition
         * Method is called only once per test class
         */
        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            base.OneTimeSetup(test);
        }

        /**
         * Method to call SetUp() from BaseTest
         * Method is called after every test scenario
         */
        [SetUp]
        public new void Setup()
        {
            base.Setup();
            this.driver = base.GetDriver();
            this.test = base.GetTest();
        }

        /**
         * Method to call TearDown() from BaseTest
         * Method is called after every test scenario
         */
        [TearDown]
        public new void TearDown()
        {
            base.TearDown();
        }

        /**
         * Method to call OneTimeTearDown() from BaseTest
         * Method is only called when all test scenarios are done running
         */
        [OneTimeTearDown]
        public new void OneTimeTearDown()
        {
            base.OneTimeTearDown();
        }


        //***********************************************************************************//
        //**                                  Scenario 1                                   **//
        //** Client Profile Page: Credit Splitting Link                                    **//
        //***********************************************************************************//
        [Test]
        public void Test_ITRDS_English_CreditSplittingLink()
        {
            test.Log(Status.Info, "Start Testing: " + TestContext.CurrentContext.Test.MethodName);
            HomePage homePage = new HomePage(driver, testContext, test);
            var homePageElements = new HomePageElements();

            //Landing on ITRDS English page
            homePage.ITRDS_Login(pageUrl, homePageElements.itrdsEnglish, homePageElements.userName, homePageElements.userPass, homePageElements.btnOk, homePageElements.btnTerminate, homePageElements.btnLogOut, findClientEnglishPageUrl);

            //Provide Identifier/SIN number and Search
            homePage.InputText(homePageElements.inputIdentifier, userSIN);
            homePage.ClickElement(homePageElements.btnClientSearch);

            //Click Credit Splitting
            homePage.ClickMenu(homePageElements.englishCreditSplittingLink, creditSplettingPageEngTitle);

            //Credit Splitting Page: URL
            string actualPageUrl = homePage.GetPageUrl();
            homePage.AssertText(creditSplettingEnglishUrl, actualPageUrl);
            test.Log(Status.Info, "Checked Credit Splitting Page URL: " + userUrl + TestContext.CurrentContext.Test.MethodName);

            //Credit Splitting Page: Title
            string actualPageTitle = homePage.GetPageTitle();
            homePage.AssertText(creditSplettingPageEngTitle, actualPageTitle);
            test.Log(Status.Info, "Checked Credit Splitting Page Title: " + userPageTitle + TestContext.CurrentContext.Test.MethodName);

            test.Log(Status.Info, "Checked Credit Splitting Link. " + TestContext.CurrentContext.Test.MethodName);

            //Click Divided UPE
            homePage.ClickElement(homePageElements.englishDividedUPELink);

            //User Page: Logout
            homePage.ClickElement(homePageElements.btnLogOut);

            test.Log(Status.Info, "End Testing: " + TestContext.CurrentContext.Test.MethodName);
        }


    }
}

