﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 * 
 * Date: July 17, 2020
 * 
 * HomePageElements: Locators
 * Class that holds all page elements to be used for testing
 */

using OpenQA.Selenium;


namespace ESDC.CPPE.FunctionalTests.TestObjects
{
    class HomePageElements
    {

        //ITRDS Home Page
        public By userName = By.Id("name");
        public By userPass = By.Id("password");
        public By btnOk = By.XPath("//html/body/table/tbody/tr[8]/td/form/table/tbody/tr[6]/td/a[1]/img");
        public By btnLogOut = By.XPath("/html/body/div/div/div[2]/div/header/div/div/div/section[1]/ul/li[3]/a");
        public By btnUserLogOut = By.XPath("/html/body//table/tbody/tr/td[3]/table/tbody/tr/td[3]/a");
        public By itrdsEnglish = By.XPath("//form[@name = 'welcomeForm']/table/tbody/tr[5]/td/a/img[@title = 'English']");
        public By itrdsEnglishxxx = By.XPath("xxx']");
        public By itrdsFrench = By.XPath("//form[@name = 'welcomeForm']/table/tbody/tr[5]/td/a/img[@title = 'Français']");

        //
        public By btnTerminate = By.Id("terminateSessionYesButton");


        //ITRDS Find Client Page
        public By userLink = By.LinkText("User");
        public By inputIdentifier = By.Id("identifier");
        public By btnClientSearch = By.Id("identifierSearchButton");

        //public By englishcurrentLink = By.XPath("//html//div[@id = 'clientCommonLeftNavBar']//form[@name = 'navigationbar']//details[@id = 'left_navigation_bar_current']/summary");     
        public By englishCurrentLink = By.LinkText("Current");
        //public By englishCreditSplittingLink = By.LinkText("Credit Splitting");
        public By englishCreditSplittingLink = By.XPath("//a[normalize-space() = 'Credit Splitting']");
        //public By englishCreditSplittingLink = By.XPath("//a[contains(text(), 'Credit Splitting']");
        //public By englishCreditSplittingLink = By.XPath("//html//div[@id = 'clientCommonLeftNavBar']//form[@name = 'navigationbar']//details[@id = 'left_navigation_bar_current']/a[@id = 'creditsplitting19']");
        //public By englishCreditSplittingLink = By.XPath("//a[starts-with(@href,'javascript:submitClientLeftNavigationFormWithDirtyCheck(&quot;creditsplitting&quot;)']");

        //public By frenchCreditSplittingLink = By.LinkText("Partage des crédits");
        public By frenchCreditSplittingLink = By.XPath("//a[normalize-space() = 'Partage des crédits']");

        public By englishDividedUPELink = By.LinkText("Divided UPE");        
        public By frenchDividedUPELink = By.LinkText("GNAP Partagé");


        //ITRDS Divided UPE Page
        public By yearHeader = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[1]/th[1]");
        public By clientHeader = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[1]/th[2]");
        public By clientHeaderCPPUPE = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[1]");
        public By clientHeaderCPPUPEBef = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[3]/th[1]");
        public By clientHeaderCPPUPEAft = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[3]/th[2]");
        public By clientHeaderQPPDivided = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[2]");
        public By clientHeaderCPPReason = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[3]");

        public By SpouseHeader = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[1]/th[3]");
        public By SpouseHeaderSIN = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[4]");
        public By SpouseHeaderCPPUPE = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[5]");
        public By SpouseHeaderCPPUPEBef = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[3]/th[3]");
        public By SpouseHeaderCPPUPEAft = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[3]/th[4]");
        public By SpouseHeaderQPPDivided = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[6]");
        public By SpouseHeaderCPPReason = By.XPath("//div[@id = 'tableDividedUPE_wrapper']/table[@id = 'tableDividedUPE']/thead/tr[2]/th[7]");


        //ITRDS User Page
        public By labelFirstName = By.XPath("//form[@name = 'userSearchForm']//table/tbody/tr[1]/th/label");   ////   [contains(text(), 'First Name:']");
        public By inputFirstName = By.XPath("//table//tr[1]//td/input[@id = 'firstName']");
        public By labelSurname = By.XPath("//table//tr[2]//label");   ///   [contains(text(), 'Surname:']");
        public By inputSurname = By.XPath("//table//tr[2]//td/input[@id = 'surname']");
        public By labelUserId = By.XPath("//table//tr[4]//label");    ///   [contains(text(), 'User ID:']");
        public By inputUserId = By.Id("userId");

        public By labelNotFoundInfo = By.XPath("//table/tbody/tr/td[@class = 'infolabel']");    ///   [contains(text(), 'No records found']");

        //public By btnReset = ...
        public By btnSearch = By.XPath("//tr/td//a/img[@title = 'Search']");
        public By btnAdd = By.XPath("//tr/td//a/img[@title = 'Add']");
        public By btnCancel = By.XPath("//tr/td//a/img[@title = 'Cancel']");

        public By googleSearch = By.Name("q");
        public By googleSearchXXX = By.Name("qQ");
    }
}

