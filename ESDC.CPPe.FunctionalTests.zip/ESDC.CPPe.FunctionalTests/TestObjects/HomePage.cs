﻿/**
 * @Author Walid Warde
 * @Contact www.linkedIn.com/in/wwarde
 *
 * Date: July 17, 2020
 *
 * HomePage: Methods
 */
using NUnit.Framework;
using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Runtime.CompilerServices;
using AventStack.ExtentReports;
using System.Threading;

namespace ESDC.CPPE.FunctionalTests.TestObjects
{
    public class HomePage : BaseTest
    {
        private static int cDefaultWaitTimeInSec = 40;

        private IWebDriver driver;
        private ExtentTest test = null;
        public static string userName;
        public static string userPass;

        HomePageElements homePageElements = new HomePageElements();

        /**
         * Constructor method for Homepage
         */
        public HomePage(IWebDriver driver, TestContext testContext, ExtentTest test)
        {
            this.driver = driver;
            this.test = test;
        }

        /**
         * Takes in a String URL parameter and navigates to it
         */
        public void GotoUrl(String thisUrl, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                driver.Navigate().GoToUrl(thisUrl);
                test.Log(Status.Info, "Navigate to Page URL: " + thisUrl + " " + TestContext.CurrentContext.Test.MethodName);

            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Navigate to the Page URL. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }
        }

        /**
         * Returns the title of the current page
         */
        public String GetPageTitle([CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var pageTitle = driver.Title.ToString();
                return pageTitle;
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Get the Page Title. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Returns a String with the URL of the current page
         */
        public String GetPageUrl([CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var pageUrl = driver.Url.ToString();
                return pageUrl;
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Get the Page URL. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Navigates to the previous web page (same as clicking the back button)
         */
        public void NavigateBackward([CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                driver.Navigate().Back();
                test.Log(Status.Info, "Navigate Backward. " + TestContext.CurrentContext.Test.MethodName);

            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Navigate Backward. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }
        }

        /**
         * Method to type Login credentials on a page and clicks on sign in button
         */
        public void LoginCredentials(By userLocator, By pwdLocator, By btnOk, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var userNameElement = driver.FindElement(userLocator);
                var passwordElement = driver.FindElement(pwdLocator);
                var okElement = driver.FindElement(btnOk);

                userName = TestContext.Parameters["userName"]?.ToString();
                userPass = TestContext.Parameters["userPass"]?.ToString();

                Thread.Sleep(1000);
                userNameElement.Clear();
                passwordElement.Clear();
                userNameElement.SendKeys(userName);
                passwordElement.SendKeys(userPass);
                okElement.Click();

            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Failed to Login. Please Provide the Valid Credentials. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }
        }


        /**
        * Method to Login by given Language and locators
        */
        public void ITRDS_Login(string pageUrl, By btnLanguage, By inputUser, By inputPass, By btnOk, By btnYesTerminate, By btnLogout, String findClientPageUrl,
        [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                //Landing on ITRDS page
                GotoUrl(pageUrl);

                //Click Language Button
                ClickElement(btnLanguage);

                //Provide Credintials and Login
                LoginCredentials(inputUser, inputPass, btnOk);
                String actualPageTitle = GetPageTitle();
                if (actualPageTitle.Equals("Terminate Session") || actualPageTitle.Equals("Terminer la session"))
                {
                    ClickElement(btnYesTerminate);
                    ClickElement(btnLogout);

                    //Landing on ITRDS page
                    GotoUrl(pageUrl);

                    //Click Language Button
                    ClickElement(btnLanguage);

                    //Provide Credintials and Login
                    LoginCredentials(inputUser, inputPass, btnOk);
                }
                string actualPageUrl = GetPageUrl();
                AssertText(findClientPageUrl, actualPageUrl);
                test.Log(Status.Info, "Checked Login. " + TestContext.CurrentContext.Test.MethodName);
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Failed to Login. Please Provide the Valid Credentials. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }
        }

        /**
        * Method to click on element given by locator
         */
        public void ClickElement(By locator, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var textControlElement = driver.FindElement(locator);
                textControlElement.Click();
                Thread.Sleep(3000);
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Click Button. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }


        /**
        * Method to click on menu element given by locator
        */
        public void ClickMenu(By locator, string theLink, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                int i = 0;
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(cDefaultWaitTimeInSec));
                var textControl = wait.Until(d =>
                {
                    var textControlElement = driver.FindElement(locator);
                    string link = textControlElement.Text.ToString();
                    Thread.Sleep(1000);
                    while (!link.Equals(theLink) && i < 10)
                    {
                        Console.WriteLine("The link is: " + link);
                        test.Log(Status.Info, "The link is: " + link);
                        textControlElement = driver.FindElement(locator);
                        link = textControlElement.Text.ToString();
                        Thread.Sleep(1000);
                        i++;
                    }
                    Console.WriteLine("The link is: " + link);
                    test.Log(Status.Info, "The link is: " + link);
                    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                    executor.ExecuteScript("arguments[0].click();", textControlElement);
                    Thread.Sleep(3000);
                    return textControlElement;
                });
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Click Button. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }




        /**
         * Method to input text into a textfield found by a locator
         */
        public void InputText(By locator, string text, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                int i = 0;
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(cDefaultWaitTimeInSec));
                var textControl = wait.Until(d =>
                {
                    var textControlElement = driver.FindElement(locator);
                    if (textControlElement != null)
                    {
                        textControlElement.Clear();
                        Thread.Sleep(1000);
                        textControlElement.SendKeys(text);
                        Thread.Sleep(1000);
                        while (!GetInputText(locator).Equals(text) && i < 10)
                        {
                            Thread.Sleep(1000);
                            textControlElement.SendKeys(text);
                            Thread.Sleep(1000);
                            i++;
                        }
                        return textControlElement;
                    }
                    return null;
                });
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Locate Input Box and Provide a Text. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Retrives text in a textfield given by a locator
         */
        public String GetInputText(By locator, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(cDefaultWaitTimeInSec));
                var textControl = wait.Until(d =>
                {
                    var textControlElement = driver.FindElement(locator);
                    if (textControlElement != null)
                    {
                        return textControlElement;
                    }
                    return null;
                });

                return textControl.GetAttribute("value");
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Locate Input Box and Get the Text. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Clears a textfield by a given locator
         */
        public void ClearInputText(By locator, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(cDefaultWaitTimeInSec));
                var textControl = wait.Until(d =>
                {
                    var textControlElement = driver.FindElement(locator);
                    if (textControlElement != null)
                    {
                        textControlElement.Clear();
                        Thread.Sleep(1000);
                        return textControlElement;
                    }
                    return null;
                });
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Locate Input Box and Clear a Text. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Checks if element exists on page by a given locator
         */
        public bool IsExist(By locator, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "", [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var textControlElement = driver.FindElement(locator);
                return true;
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Find the Element. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }

        /**
         * Method to handle pop up alerts on web page
         */
        public void Alert(string text, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var alert = driver.SwitchTo().Alert();
                Assert.AreEqual(text, alert.Text.ToString());
                alert.Accept();
                Thread.Sleep(1000);

            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " Could not Find the Alert Text. " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                e.GetBaseException();
                e.StackTrace.ToUpper();
                throw e;
            }

        }



        /**
         * Method to check if two given Strings are equal
         */
        public void AssertText(string ExpectedText, string ActualText, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                Assert.AreEqual(ExpectedText, ActualText);
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                throw e;
            }
        }

        /**
         * Method to check if a String is conatined anywhere within another string
         */
        public void AssertPartialText(string ExpectedText, string ActualText, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                Assert.True(ActualText.Contains(ExpectedText));
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                throw e;
            }
        }

        /**
         * Method to check if Element text on page is correct
         */
        public void AssertElementLable(By locator, string text, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var textControlElement = driver.FindElement(locator);
                Assert.AreEqual(text, textControlElement.Text.ToString());
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                throw e;
            }
        }



        /**
        * Method to check if Element text on page is correct
        */
        public bool DoesLabelEist(By locator, string text, [CallerLineNumber] int sourceLineNumber = 0, [CallerMemberName] string memberName = "",
        [CallerFilePath] string sourceFilePath = "")
        {
            try
            {
                var textControlElement = driver.FindElement(locator);
                Assert.AreEqual(text, textControlElement.Text.ToString());
                return true;
            }
            catch (Exception e)
            {
                test.Log(Status.Error, e.Message + " " + memberName + " " + sourceFilePath + " At Line: " + sourceLineNumber);
                throw e;
            }
        }









    }
}
